
- Edit JQuake.sh by replacing [JAR Folder] by the path containing JQuake.jar

- Set JQuake.sh as executable

For Ubuntu users, you can set a script to be executable on click by this command :

gsettings set org.gnome.nautilus.preferences executable-text-activation 'launch'

- Launch by executing JQuake.sh
