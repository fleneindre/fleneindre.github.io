#!/usr/bin/env bash
cd [JAR FOLDER]
java -jar JQuake.jar -Xmx200m -Xms32m -Xmn2m


